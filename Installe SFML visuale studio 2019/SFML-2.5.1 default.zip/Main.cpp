/*
* SFML-2.5.1 Default projet (Dynamic Link)
* --------------------------------------------------------------------------------------------
*
* V�rifier bien que le fichier SFML-2.5.1 soit bien installe dans le C:/
* Si il n'y est pas, t�l�charger le sur https://www.sfml-dev.org/download/sfml/2.5.1/index-fr.php
* Si il ne pas dans le disque dur C:/ , modifier les param�tres suivants :
*
* Cliquer droit sur le projet -> Propri�t� (Toutes les configurations) -> C/C++ -> autre
* r�pertoire inclus -> mettez le lien qui doit inclure obligatoirement \SFML-2.5.1\include
* Ensuite !
* Dans Editeur de lien -> r�pertoire de biblioth�que suppl�mentaire -> mettez le lien qui doit
* inclure obligatoirement \SFML-2.5.1\lib
*
* --------------------------------------------------------------------------------------------
* Pour utilise la Release ou Debug sans visuale studio, il faut copier/colle les fichiers qui
* ce touve dans "Fichiers SFML" (.dll) dans le fichier de la Release ou Debug
* --------------------------------------------------------------------------------------------
*/

#include <SFML/Graphics.hpp>

int main()
{
	sf::RenderWindow window(sf::VideoMode(800, 600), "Not Tetris");

	sf::Event event;

	while (window.isOpen()) {

		while (window.pollEvent(event)) {

			if (event.type == sf::Event::Closed) {

				window.close();
			}
		}
	}

	return 0;
}